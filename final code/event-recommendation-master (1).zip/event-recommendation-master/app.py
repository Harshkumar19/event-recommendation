from cProfile import run
import re
import random
from flask import Flask, request, render_template, session, redirect, url_for
from flask_session import Session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import pickle

# create an instance
app = Flask(__name__, template_folder='template')

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

app.static_folder = 'static'
app.secret_key = 'secret' 

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'event'

mysql = MySQL(app)

@app.route('/')
def home():
    if not session.get("name"):
        return redirect('/login')
    return render_template('index.html')

events = pickle.load(open('./models/events2.pkl','rb'))
similarity = pickle.load(open('./models/similarity2.pkl','rb'))

def getFriend():
    user_id = session['id']
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT friend_id FROM friends WHERE user_id = % s', (user_id, ))
    account = cursor.fetchall()
    acc = []
    for i in account:
        temp = list(i.values())[0]
        acc.append(temp)
    return acc

def getRandomFriendid(acc):
    friendAc = random.choice(acc)
    return friendAc

@app.route('/profile')
def profile():
    #Connecting friends
    user_id = session['id']
    friends = getFriend()   

    #Get username from user table 
    username = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    for i in friends:
        temp = cursor.execute('SELECT username from users where user_id = %s', (int(i), ))
        # username.append(temp)
        username = temp
    

    return render_template('profile.html', user=user_id, username=username)

@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    ses = None
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = % s AND password = % s', (username, password, ))
        account = cursor.fetchone()

        if account:
            status = True
            session['loggedin'] = True
            session['id'] = account['user_id']
            session['username'] = account['username']
            msg = 'Logged in successfully !'
            return render_template('index.html', msg = msg, status = status)
        else:
            msg = 'Incorrect username / password !'

        ses = session['loggedin']
    return render_template('login.html', msg = msg, ses=ses)
 
@app.route('/movies' , methods = ["POST"])
def movies():
    ses = session['loggedin']
    if request.method == 'POST':
        event = request.form['movie']
        index = events[events['name'] == event].index[0]
        distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
        recommended_event_names = []
        for i in distances[1:6]:
            event_id = events.iloc[i[0]].event_id
            recommended_event_names.append(events.iloc[i[0]]['name'])
        event_list = events['name'].values
        ans = list(recommended_event_names[:5])

        friends = getFriend()
        randomFriendId = int(getRandomFriendid(friends))

        #For testing purposes, uncomment when in development
        randomFriendId = 1
        # --------------------------------------------------

        friendsEvent = []
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT event_id FROM attendingEvent WHERE user_id = %s', (randomFriendId, ))
        TEMP = cursor.fetchall()
        for i in TEMP:
            temp = list(i.values())[0]
            friendsEvent.append(temp)

        #Getting a random event
        randomEventId = random.choice(friendsEvent)

        cursor.execute('SELECT event_name FROM allEvents WHERE event_id = %s', (randomEventId, ))

        FriendEvent = str(list(cursor.fetchone().values())[0])
        index = events[events['name'] == FriendEvent].index[0]
        distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
        friends_recommended_event_names = []
        for i in distances[1:6]:
            event_id = events.iloc[i[0]].event_id
            friends_recommended_event_names.append(events.iloc[i[0]]['name'])
        event_list = events['name'].values
        ans = list(friends_recommended_event_names[:5])
        
        if isinstance(ans,list): return render_template('index.html', recommend = ans, ses=ses, friends = friends_recommended_event_names, temp = FriendEvent)
        else: return render_template('index.html', recommendSelf = ans, ses=ses, friends = friends_recommended_event_names, temp = FriendEvent)

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None) 
    return redirect(url_for('login'))

@app.route('/register', methods =['GET', 'POST'])
def register(): 
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = % s', (username, ))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers !'
        elif not username or not password or not email:
            msg = 'Please fill out the form !'
        else:
            cursor.execute('INSERT INTO users VALUES (NULL, % s, % s, % s)', (username, password, email, ))
            mysql.connection.commit()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)

app.run(debug=True)